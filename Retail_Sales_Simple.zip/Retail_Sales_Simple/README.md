# Retail Sales Analysis - Simple Version
Data Analyst Internship - StarCentauri Technologies

The data is a **sample file**, not real company data. Raw file: 9,989 rows. After cleaning: 9,872 rows.

## Files
- `Retail_Sales_Analysis.ipynb` - the notebook (start here). Section 10 makes the Power BI files.
- `data/raw/` original file, `data/cleaned/` cleaned file
- `charts/` 6 pictures (3 charts, data model, 2 dashboard layouts)
- `powerbi/` the 4 data files for Power BI + `PowerBI_Guide.pdf/.docx` (steps, formulas, page layouts)
- `report/Short_Report.pdf` and `.docx` - 2-page report
- `presentation/Retail_Sales_Presentation.pptx` (and .pdf) - 9 slides including both dashboards

## How to run
1. `pip install pandas matplotlib jupyter`
2. Run `jupyter notebook` in this folder
3. Open the notebook and click **Kernel > Restart & Run All**

## Please note
- The Power BI file (`.pbix`) is **not included** - it can only be made in Power BI Desktop. Follow `powerbi/PowerBI_Guide.pdf` (about 1 hour). The DAX formulas have not been run in Power BI, so test them there.
- The dashboards in the PPT and guide are layout designs made from the same data, not Power BI screenshots.
- Fill the [brackets] in the report and the PPT (mentor name, dates, signature).
